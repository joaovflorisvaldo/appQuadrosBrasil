package com.example.quadrosbrasil;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        View cdCliente = findViewById(R.id.cdCliente);
        View cdQuadros = findViewById(R.id.cdQuadro);
        View cdPedido = findViewById(R.id.cdPedido);

        cdCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { cadastroCliente();}
        });

        cdQuadros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { cadastroQuadros();}
        });

    }

    public void cadastroCliente(){
        Intent intent = new Intent(MainActivity.this, cadastro_cliente.class );
        startActivity(intent);
    }
    public void cadastroQuadros(){
        Intent intent = new Intent(MainActivity.this, cadastro_quadro.class);
        startActivity(intent);
    }
}
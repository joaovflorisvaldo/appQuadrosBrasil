package com.example.quadrosbrasil.controller;

import com.example.quadrosbrasil.classes.clientes;
import java.util.ArrayList;

public class ControllerClientes {
    private static ControllerClientes instanciaCliente;
    private ArrayList<clientes> lsClientes;

    public static ControllerClientes getInstanciaCliente(){
        if(instanciaCliente == null){
            return instanciaCliente = new ControllerClientes();
        }else{
            return instanciaCliente;
        }
    }
    private ControllerClientes(){
        lsClientes = new ArrayList<>();
    }
    public void svCliente(clientes clientes){
        lsClientes.add(clientes);
    }

    public ArrayList<clientes> rtrCliente() {
        return lsClientes;
    }
}


package com.example.quadrosbrasil;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.quadrosbrasil.classes.clientes;
import com.example.quadrosbrasil.classes.quadros;
import com.example.quadrosbrasil.controller.ControllerClientes;
import com.example.quadrosbrasil.controller.controllerQuadros;

public class cadastro_quadro extends AppCompatActivity {
    private EditText nomeQuadro;
    private EditText skuQuadro;
    private EditText dscQuadro;
    private EditText vlrQuadro;
    private Button svQuadro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro_quadro);
        nomeQuadro = findViewById(R.id.nomeQuadro);
        skuQuadro = findViewById(R.id.skuQuadro);
        dscQuadro = findViewById(R.id.dscQuadro);
        vlrQuadro = findViewById(R.id.vlrQuadro);
        svQuadro = findViewById(R.id.svQuadro);

        svQuadro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastroQuadro();
                onRestart();
            }
        });
    }

    private void cadastroQuadro() {
        if(nomeQuadro.getText().toString().isEmpty()){
            nomeQuadro.setError("Informe o NOME do quadro");
            return;
        }
        if(skuQuadro.getText().toString().isEmpty()){
            skuQuadro.setError("Informe o SKU do quadro");
            return;
        }
        if(dscQuadro.getText().toString().isEmpty()){
            dscQuadro.setError("Informe a DESCRIÇÃO do quadro");
            return;
        }
        if(vlrQuadro.getText().toString().isEmpty()){
            vlrQuadro.setError("Informe o VALOR do quadro");
            return;
        }
        quadros quadros = new quadros();
        quadros.setNome(nomeQuadro.getText().toString());
        quadros.setSku(Integer.parseInt(skuQuadro.getText().toString()));
        quadros.setDescricao(dscQuadro.toString().toString());
        quadros.setValor(Double.parseDouble(skuQuadro.getText().toString()));

        controllerQuadros.getInstanciaItem().salvaQuadro(quadros);
        finish();
    }
    @Override
    protected void onRestart(){
        super.onRestart();
        Toast.makeText(cadastro_quadro.this, "QUADRO CADASTRADO", Toast.LENGTH_LONG).show();
    }
}
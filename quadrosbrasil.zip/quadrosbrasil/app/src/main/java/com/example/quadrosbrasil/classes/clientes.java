package com.example.quadrosbrasil.classes;

public class clientes {
    private String nome;
    private String cpf;

    public clientes() {}

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
}

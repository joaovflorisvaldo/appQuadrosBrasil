package com.example.quadrosbrasil.controller;

import com.example.quadrosbrasil.classes.quadros;
import java.util.ArrayList;

public class controllerQuadros {
    private static controllerQuadros instanciaItem;
    private ArrayList<quadros> lsQuadros;

    public static controllerQuadros getInstanciaItem(){
        if(instanciaItem == null){
            return instanciaItem = new controllerQuadros();
        }else{
            return instanciaItem;
        }
    }
    private controllerQuadros(){
        lsQuadros = new ArrayList<>();
    }
    public void salvaQuadro(quadros quadros){
        lsQuadros.add(quadros);
    }
    public ArrayList<quadros> rtrQuadros(){
        return lsQuadros;
    }
}


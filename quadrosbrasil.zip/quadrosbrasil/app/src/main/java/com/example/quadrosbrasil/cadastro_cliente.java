package com.example.quadrosbrasil;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quadrosbrasil.classes.clientes;
import com.example.quadrosbrasil.controller.ControllerClientes;


public class cadastro_cliente extends AppCompatActivity{
    private EditText nomeCliente;
    private EditText cpfCliente;
    private TextView lsClientes;
    private Button svCliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro_cliente);
        nomeCliente = findViewById(R.id.nomeCliente);
        cpfCliente = findViewById(R.id.cpfCliente);
        lsClientes = findViewById(R.id.lsClientes);
        svCliente = findViewById(R.id.svCliente);

        atualizaListaCliente();

        svCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvaCliente();
            }
        });
    }
    private void salvaCliente(){
        if(nomeCliente.getText().toString().isEmpty()){
            nomeCliente.setError("Insira o nome do cliente");
            return;
        }
        int cpf = 0;
        try {
            cpf = Integer.parseInt(cpfCliente.getText().toString());
        } catch (Exception ex) {
            cpfCliente.setError("Insira o cpf do Cliente");
            return;
        }

        clientes clientes = new clientes();
        clientes.setNome(nomeCliente.getText().toString());
        clientes.setCpf(cpfCliente.getText().toString());
        ControllerClientes.getInstanciaCliente().svCliente(clientes);
        Toast.makeText(cadastro_cliente.this, "CLIENTE CADASTRADO!!!", Toast.LENGTH_LONG).show();
        finish();
    }
    private void atualizaListaCliente(){
        String text = "";
        for(clientes clientes : ControllerClientes.getInstanciaCliente().rtrCliente()){
            text += "Nome: " + clientes.getNome() + "CPF: " + clientes.getCpf() + "\n" + "====================================\n";
        }
        lsClientes.setText(text);
    }
}
